package com.example.bcc_1;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class LoginActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
    }

    public void mClick (View v) {
        if(v.getId() == R.id.login_back){
            Intent intent_back_login = new Intent(this, MainActivity.class);
            startActivity(intent_back_login);
        } else {
            Intent intent_menu = new Intent(this, MenuActivity.class);
            startActivity(intent_menu);
        }

    }



}
