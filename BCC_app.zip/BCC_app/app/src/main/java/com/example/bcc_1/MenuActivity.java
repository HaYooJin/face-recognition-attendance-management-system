package com.example.bcc_1;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MenuActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
    }

    public void mClick_m (View v) {
        if(v.getId() == R.id.menu_back){
            Intent intent_back_menu = new Intent(this,LoginActivity.class);
            startActivity(intent_back_menu);
        } else if(v.getId() == R.id.menu_start_button) {
            Intent intent_menu_start = new Intent(this, CheckActivity.class);
            startActivity(intent_menu_start);
        } else {
            Intent intent_menu_check = new Intent(this, StartActivity.class);
            startActivity(intent_menu_check);
        }
    }

}
