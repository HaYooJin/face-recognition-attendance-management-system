package com.example.bcc_1;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.Nullable;

public class StartActivity extends Activity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start);

        TextView textView1 = (TextView) findViewById(R.id.start_user_name) ;
        textView1.setText("반천천 교수님") ;
    }

    public void mClick_s (View v) {
        Intent intent_back_start = new Intent(this, MenuActivity.class);
        startActivity(intent_back_start);
    }
}
