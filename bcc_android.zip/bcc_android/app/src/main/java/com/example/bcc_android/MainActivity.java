package com.example.bcc_android;

protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        test = "http://192.168.0.3/MediumServer/SelectAllPost.php";
        task = new URLConnector(test);

        task.start();

        try{
        task.join();
        System.out.println("waiting... for result");
        }
        catch(InterruptedException e){

        }

        String result = task.getResult();

        System.out.println(result);
        }


